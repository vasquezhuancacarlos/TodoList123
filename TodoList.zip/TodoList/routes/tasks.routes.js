// Importamos Express
const express = require('express');

// Creamos router
const router = express.Router();

// Importamos controladores
const {
    getTasks,
    getTaskById,
    createTask,
    updateTask,
    deleteTask
} = require('../controllers/tasks.controller');

